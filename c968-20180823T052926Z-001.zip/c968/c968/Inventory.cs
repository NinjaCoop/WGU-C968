﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c968
{
    class Inventory
    {
        BindingList<Product> Products = new BindingList<Product>();
        static BindingList<Part> Parts = new BindingList<Part>();

        // Products Methods
        // TO TEST
        public void AddProduct(Product prod)
        {
            //Check if object has data
            try
            {
                Products.Add(prod);
            }
            catch
            {
                //Show some error message
                MessageBox.Show("Addition failed.");
            }
        }

        // TO TEST
        public bool RemoveProduct(int productID)
        {
            bool success = false;
            foreach (Product prod in Products)
            {
                if (productID == prod.ProductID)
                {
                    try
                    {
                        Products.Remove(prod);
                        return success = true;
                    }
                    catch
                    {
                        MessageBox.Show("Removal failed.");
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            return success;
        }

        // TO FINISH - not all paths return a value
        //public Product LookupProduct(int productID)
        //{
        //    foreach (Product prod in Products)
        //    {
        //        if (prod.ProductID == productID)
        //        {
        //            return prod;
        //        }
        //    }
        //}

        // TO TEST
        public void UpdateProduct(int productID, Product prod)
        {
            foreach (Product updatedProd in Products)
            {
                if (updatedProd.ProductID == productID)
                {
                    updatedProd.Name = prod.Name;
                    updatedProd.InStock = prod.InStock;
                    updatedProd.Price = prod.Price;
                    updatedProd.Max = prod.Max;
                    updatedProd.Min = prod.Min;
                    return;
                }
            }

        }

        // Parts Methods
        // TO TEST
        public static void AddPart(Part part)
        {
            try
            {
                Parts.Add(part);
            }
            catch
            {
                MessageBox.Show("Addition failed.");
            }
            
        }

        // TO TEST
        public bool DeletePart(Part part)
        {
            try
            {
                Parts.Remove(part);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // TO FINISH - not all paths return a value
        //public Part LookupPart(int partID)
        //{
        //    foreach (Part part in Parts)
        //    {
        //        if (part.PartID == partID)
        //        {
        //            return part;
        //        }
        //    }
        //}

        // TO TEST
        public static void UpdatePart(int partID, Part part)
        {
            foreach (Part updatedPart in Parts)
            {
                if (updatedPart.PartID == partID)
                {
                    updatedPart.Name = part.Name;
                    updatedPart.InStock = part.InStock;
                    updatedPart.Price = part.Price;
                    updatedPart.Max = part.Max;
                    updatedPart.Min = part.Min;
                    return;
                }
            }
        }
    }
}
