﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c968
{
    public partial class ModifyPartScreen : Form
    {
        public ModifyPartScreen()
        {
            InitializeComponent();
        }

        private void btnModPartCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // TO TEST
        private void btnModPartSave_Click(object sender, EventArgs e)
        {
            int id = modPartIDBoxText;

            InHousePart inHouse = new InHousePart(modPartIDBoxText, modPartNameBoxText, modPartPriceBoxText,
                                                modPartInvBoxText, modPartMaxBoxText, modPartMinBoxText, modPartMachComBoxText);
            OutsourcedPart outSourced = new OutsourcedPart(modPartIDBoxText, modPartNameBoxText, modPartPriceBoxText,
                                                modPartInvBoxText, modPartMaxBoxText, modPartMinBoxText, modPartMachComBoxText.ToString());

            if (radioModInhouse.Checked)
            {
                Inventory.UpdatePart(id, inHouse);
            }
            else
            {
                Inventory.UpdatePart(id, outSourced);
            }
        }

        // Change textbox input type based on radio selection
        private void radioModOutsourced_CheckedChanged(object sender, EventArgs e)
        {
            label7.Text = "Company Name";
            
        }

        private void radioModInhouse_CheckedChanged(object sender, EventArgs e)
        {
            label7.Text = "Machine ID";
        }
    }
}
