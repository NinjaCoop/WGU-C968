﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c968
{
    public partial class AddPartScreen : Form
    {
        public AddPartScreen()
        {
            InitializeComponent();
        }

        private void btnAddPartCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Convert price from double to decimal?
        private void btnAddPartSave_Click(object sender, EventArgs e)
        {
            //InHousePart newPart = new InHousePart(addPartIDBoxText, addPartNameBoxText, addPartPriceBoxText,
            //                                addPartInvBoxText, addPartMaxBoxText, addPartMinBoxText, );
            //Inventory.AddPart(newPart);
        }
    }
}
