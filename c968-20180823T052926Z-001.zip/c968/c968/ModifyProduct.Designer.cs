﻿namespace c968
{
    partial class ModifyProductScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblModifyProduct = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblInv = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxInv = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxMax = new System.Windows.Forms.TextBox();
            this.textBoxMin = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSaveModProduct = new System.Windows.Forms.Button();
            this.btnCancelModProduct = new System.Windows.Forms.Button();
            this.modifyProductGrid1 = new System.Windows.Forms.DataGridView();
            this.modifyProductGrid2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.modifyProductGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.modifyProductGrid2)).BeginInit();
            this.SuspendLayout();
            // 
            // lblModifyProduct
            // 
            this.lblModifyProduct.AutoSize = true;
            this.lblModifyProduct.Location = new System.Drawing.Point(13, 13);
            this.lblModifyProduct.Name = "lblModifyProduct";
            this.lblModifyProduct.Size = new System.Drawing.Size(78, 13);
            this.lblModifyProduct.TabIndex = 0;
            this.lblModifyProduct.Text = "Modify Product";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(15, 115);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(18, 13);
            this.lblID.TabIndex = 1;
            this.lblID.Text = "ID";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(15, 155);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(35, 13);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name";
            // 
            // lblInv
            // 
            this.lblInv.AutoSize = true;
            this.lblInv.Location = new System.Drawing.Point(15, 195);
            this.lblInv.Name = "lblInv";
            this.lblInv.Size = new System.Drawing.Size(22, 13);
            this.lblInv.TabIndex = 3;
            this.lblInv.Text = "Inv";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(15, 235);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(31, 13);
            this.lblPrice.TabIndex = 4;
            this.lblPrice.Text = "Price";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Location = new System.Drawing.Point(15, 275);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(27, 13);
            this.lblMax.TabIndex = 5;
            this.lblMax.Text = "Max";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(135, 275);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(24, 13);
            this.lblMin.TabIndex = 6;
            this.lblMin.Text = "Min";
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(65, 110);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(100, 20);
            this.textBoxID.TabIndex = 7;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(65, 152);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(100, 20);
            this.textBoxName.TabIndex = 8;
            // 
            // textBoxInv
            // 
            this.textBoxInv.Location = new System.Drawing.Point(65, 192);
            this.textBoxInv.Name = "textBoxInv";
            this.textBoxInv.Size = new System.Drawing.Size(100, 20);
            this.textBoxInv.TabIndex = 9;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(65, 232);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrice.TabIndex = 10;
            // 
            // textBoxMax
            // 
            this.textBoxMax.Location = new System.Drawing.Point(65, 272);
            this.textBoxMax.Name = "textBoxMax";
            this.textBoxMax.Size = new System.Drawing.Size(50, 20);
            this.textBoxMax.TabIndex = 11;
            // 
            // textBoxMin
            // 
            this.textBoxMin.Location = new System.Drawing.Point(168, 272);
            this.textBoxMin.Name = "textBoxMin";
            this.textBoxMin.Size = new System.Drawing.Size(50, 20);
            this.textBoxMin.TabIndex = 12;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(440, 35);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(530, 37);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(160, 20);
            this.textBoxSearch.TabIndex = 16;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(635, 196);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 17;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(635, 366);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 18;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnSaveModProduct
            // 
            this.btnSaveModProduct.Location = new System.Drawing.Point(540, 409);
            this.btnSaveModProduct.Name = "btnSaveModProduct";
            this.btnSaveModProduct.Size = new System.Drawing.Size(75, 23);
            this.btnSaveModProduct.TabIndex = 19;
            this.btnSaveModProduct.Text = "Save";
            this.btnSaveModProduct.UseVisualStyleBackColor = true;
            // 
            // btnCancelModProduct
            // 
            this.btnCancelModProduct.Location = new System.Drawing.Point(635, 409);
            this.btnCancelModProduct.Name = "btnCancelModProduct";
            this.btnCancelModProduct.Size = new System.Drawing.Size(75, 23);
            this.btnCancelModProduct.TabIndex = 20;
            this.btnCancelModProduct.Text = "Cancel";
            this.btnCancelModProduct.UseVisualStyleBackColor = true;
            this.btnCancelModProduct.Click += new System.EventHandler(this.btnCancelModProduct_Click);
            // 
            // modifyProductGrid1
            // 
            this.modifyProductGrid1.AllowUserToAddRows = false;
            this.modifyProductGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.modifyProductGrid1.Location = new System.Drawing.Point(310, 70);
            this.modifyProductGrid1.Name = "modifyProductGrid1";
            this.modifyProductGrid1.Size = new System.Drawing.Size(400, 120);
            this.modifyProductGrid1.TabIndex = 21;
            // 
            // modifyProductGrid2
            // 
            this.modifyProductGrid2.AllowUserToAddRows = false;
            this.modifyProductGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.modifyProductGrid2.Location = new System.Drawing.Point(310, 240);
            this.modifyProductGrid2.Name = "modifyProductGrid2";
            this.modifyProductGrid2.Size = new System.Drawing.Size(400, 120);
            this.modifyProductGrid2.TabIndex = 22;
            // 
            // ModifyProductScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.modifyProductGrid2);
            this.Controls.Add(this.modifyProductGrid1);
            this.Controls.Add(this.btnCancelModProduct);
            this.Controls.Add(this.btnSaveModProduct);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.textBoxMin);
            this.Controls.Add(this.textBoxMax);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.textBoxInv);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.lblMax);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblInv);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.lblModifyProduct);
            this.Name = "ModifyProductScreen";
            ((System.ComponentModel.ISupportInitialize)(this.modifyProductGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.modifyProductGrid2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblModifyProduct;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblInv;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxInv;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxMax;
        private System.Windows.Forms.TextBox textBoxMin;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSaveModProduct;
        private System.Windows.Forms.Button btnCancelModProduct;
        private System.Windows.Forms.DataGridView modifyProductGrid1;
        private System.Windows.Forms.DataGridView modifyProductGrid2;
    }
}