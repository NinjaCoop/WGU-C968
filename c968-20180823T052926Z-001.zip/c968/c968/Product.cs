﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c968
{
    class Product
    {
        BindingList<Part> associatedParts = new BindingList<Part>();
        private int productID;
        private string name;
        private double price;
        private int inStock;
        private int max;
        private int min;

        public int ProductID { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int InStock { get; set; }
        public int Max { get; set; }
        public int Min { get; set; }

        public Product() { }
        public Product(int prodID, string name, double price, int inStock, int max, int min)
        {
            ProductID = prodID;
            Name = name;
            Price = price;
            InStock = inStock;
            Max = max;
            Min = min;
        }

        // To test
        public void AddAssociatedPart(Part part)
        {
            try
            {
                associatedParts.Add(part);
            }
            catch
            {
                MessageBox.Show("Addition failed");
            }
        }

        // To Test
        public bool RemoveAssociatedPart(int partID)
        {
            bool success = false;
            foreach (Part part in associatedParts)
            {
                if (part.PartID == partID)
                {
                    associatedParts.Remove(part);
                    return success = true;
                }
                else
                {
                    success = false;
                }
            }
            return success;
        }

        // To finish - not all paths return a value
        //public Part LookupAssociatedPart(int partID)
        //{
        //    //TODO - return blank part on failure?
        //    foreach (Part part in associatedParts)
        //    {
        //        if (part.PartID == partID)
        //        {
        //            return part;
        //        }
        //    }
        //}
    }
}
