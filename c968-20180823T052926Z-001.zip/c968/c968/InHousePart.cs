﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c968
{
    class InHousePart : Part
    {
        private int machineID;

        public int MachineID { get; set; }

        // Create Constructor

        public InHousePart() { }
        public InHousePart(int partID, string name, double price, int inStock, int max, int min)
        {
            PartID = partID;
            Name = name;
            Price = price;
            InStock = InStock;
            Max = max;
            Min = max;
        }

        public InHousePart(int partID, string name, double price, int inStock, int max, int min, int machineID)
        {
            PartID = partID;
            Name = name;
            Price = price;
            InStock = InStock;
            Max = max;
            Min = max;
            MachineID = machineID;
        }
    }
}
