﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c968
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        // Redirect Button Functionalities
        private void btnAddPart_Click(object sender, EventArgs e)
        {   
            new AddPartScreen().ShowDialog();
        }

        private void btnModifyPart_Click(object sender, EventArgs e)
        {
            new ModifyPartScreen().ShowDialog();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            new AddProductScreen().ShowDialog();
        }

        private void btnModifyProduct_Click(object sender, EventArgs e)
        {
            new ModifyProductScreen().ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Action Button Functionalities
        private void btnDeletePart_Click(object sender, EventArgs e)
        {
            // TODO
        }

        private void btnPartsSearch_Click(object sender, EventArgs e)
        {
            // TODO
        }
    }
}
